package acadglidassignment;

public class XPattern {
	public static void main(String... K) {
		for (int i = 0; i <5; i++)
		{
			for (int j = 0; j <5; j++) {
				if (i == j || j == (4 - i)) {
					System.out.print(" *");
				} else {
					System.out.print("_");
				}

			}
			System.out.print("\n");
		}
	}

}
